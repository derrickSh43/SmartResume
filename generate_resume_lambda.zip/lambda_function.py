import json
import boto3
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)
dynamodb = boto3.resource("dynamodb")
comprehend = boto3.client("comprehend")
s3 = boto3.client("s3")

def lambda_handler(event, context):
    frontend_domain = os.environ["FRONTEND_DOMAIN"]
    headers = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": frontend_domain,
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
        "Access-Control-Allow-Methods": "OPTIONS,POST"
    }

    try:
        logger.info(f"Event: {json.dumps(event)}")
        body = event.get("body", {})
        if isinstance(body, str):
            body = json.loads(body)
        
        user_id = body.get("userId")
        if not user_id:
            logger.error("Missing userId")
            return {
                "statusCode": 400,
                "headers": headers,
                "body": json.dumps({"message": "Missing userId"})
            }

        table = dynamodb.Table("UserProfiles")
        response = table.get_item(Key={"userId": user_id})
        if "Item" not in response:
            logger.error(f"User {user_id} not found")
            return {
                "statusCode": 404,
                "headers": headers,
                "body": json.dumps({"message": "User not found"})
            }
        
        item = response["Item"]
        skills = item.get("skills", [])
        job_description = item.get("jobDescription", "")

        entities = comprehend.detect_entities(Text=job_description, LanguageCode="en")
        key_phrases = comprehend.detect_key_phrases(Text=job_description, LanguageCode="en")

        job_skills = [entity["Text"] for entity in entities["Entities"] if entity["Type"] in ["OTHER", "SKILL"]]
        matched_skills = [skill for skill in skills if skill in job_skills or skill.lower() in job_description.lower()]

        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head><title>Resume for {user_id}</title></head>
        <body>
            <h1>Resume for {user_id}</h1>
            <h2>Matched Skills</h2>
            <ul>{''.join(f'<li>{skill}</li>' for skill in matched_skills)}</ul>
            <h2>Job Description Summary</h2>
            <p>{job_description[:200]}...</p>
        </body>
        </html>
        """

        bucket = "resumerx-resumes-5y3lp26l"
        key = f"resumes/{user_id}/resume.html"
        s3.put_object(Body=html_content.encode('utf-8'), Bucket=bucket, Key=key, ContentType="text/html")

        url = s3.generate_presigned_url(
            "get_object",
            Params={"Bucket": bucket, "Key": key},
            ExpiresIn=3600
        )
        logger.info(f"Generated resume for {user_id}")

        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps({"resumeUrl": url})
        }
    except Exception as e:
        logger.error(f"Error: {str(e)}", exc_info=True)
        return {
            "statusCode": 500,
            "headers": headers,
            "body": json.dumps({"message": "Error generating resume", "error": str(e)})
        }