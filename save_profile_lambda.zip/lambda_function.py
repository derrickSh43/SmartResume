import json
import boto3
import os
import logging
import datetime  # Added

logger = logging.getLogger()
logger.setLevel(logging.INFO)
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("UserProfiles")

def lambda_handler(event, context):
    frontend_domain = os.environ["FRONTEND_DOMAIN"]
    headers = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": frontend_domain,
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
        "Access-Control-Allow-Methods": "OPTIONS,POST"
    }

    try:
        logger.info(f"Event: {json.dumps(event)}")
        body = event.get("body", {})
        if isinstance(body, str):
            body = json.loads(body)
        
        user_id = body.get("userId")
        skills = body.get("skills")
        job_description = body.get("jobDescription")

        if not user_id or not skills or not job_description:
            logger.error("Missing required fields")
            return {
                "statusCode": 400,
                "headers": headers,
                "body": json.dumps({"message": "Missing required fields: userId, skills, and jobDescription are all required"})
            }

        item = {
            "userId": user_id,
            "skills": skills,
            "jobDescription": job_description,
            "timestamp": datetime.datetime.utcnow().isoformat()  # Fixed
        }
        table.put_item(Item=item)
        logger.info(f"Saved profile for {user_id}")

        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps({"message": "Profile saved", "userId": user_id})
        }
    except Exception as e:
        logger.error(f"Error: {str(e)}", exc_info=True)
        return {
            "statusCode": 500,
            "headers": headers,
            "body": json.dumps({"message": "Error saving profile", "error": str(e)})
        }